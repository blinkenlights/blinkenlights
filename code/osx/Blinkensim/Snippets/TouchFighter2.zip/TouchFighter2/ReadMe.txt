TouchFighter2

TouchFighter2 is an OpenGL ES game that shows how to handle and calibrate accelerometer data, recognize gestures, handle multiplayer, add a movie sequence, and get maximum OpenGL ES performance. 

By looking at the code, you'll earn how to organize a large OpenGL game project. 

TouchFighter2 uses physics to give realistic movements and collisions. 

It uses particle system classes for fire and smoke effects. You can reuse the core game objects in your own game.

Build Requirements

iPhone SDK, Mac OS X 10.5.3

Runtime Requirements

iPhone OS 2.0